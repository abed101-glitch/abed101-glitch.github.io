# Abed Gazi — Portfolio Website

A responsive, animated, dark-theme portfolio built with plain HTML, CSS and JavaScript.

## Run locally
1. Extract the ZIP.
2. Open `index.html` in a browser.

For a local development server, run:
```bash
python3 -m http.server 8000
```
Then visit http://localhost:8000.

## Deploy free
### GitHub Pages
1. Create a GitHub repository named `abed101-glitch.github.io` (or any repository).
2. Upload the contents of this folder to the repository root.
3. In GitHub: Settings → Pages → Deploy from a branch → `main` / root.
4. Your site will be published at the GitHub Pages URL shown there.

### Netlify
1. Sign in to Netlify.
2. Choose Add new site → Deploy manually.
3. Drag the extracted `abed-gazi-portfolio` folder into the deploy area.

## Before publishing
- Confirm that the listed job titles, dates, and responsibilities are accurate.
- Add your LinkedIn URL if you want it shown.
- Replace any project descriptions or metrics that you cannot substantiate.
- The CNI Global and American Standard International School descriptions are intentionally brief because detailed duties were not supplied.
